import React from 'react';
import { View, Text } from 'react-native';

const JuzzScreen = () => {
  return (
    <View>
      <Text>Juzz Screen</Text>
    </View>
  );
};

export default JuzzScreen;

